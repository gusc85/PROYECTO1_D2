/* 
 * File:   config.h
 * Author: julio
 *
 * Created on 10 de agosto de 2023, 11:35 PM
 */

#ifndef config_H
#define	config_H

#include <xc.h> // include processor files - each processor file is guarded.  


void configOsc(uint16_t freq);
void configPort(void);
void pullup(void);
void configIntbits(void);
void ioc_init(char pin);
void config_timer0(void);

#endif	/* config_H */