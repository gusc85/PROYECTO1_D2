/*
 * File:   main.c
 * Author: julio
 *
 * Created on 10 de agosto de 2023, 09:51 PM
 */

// PIC16F887 Configuration Bit Settings

// 'C' source line config statements

// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF         // Low Voltage Programming Enable bit (RB3/PGM pin has PGM function, low voltage programming enabled)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

//**********************************************************************************************
//prototipos de funciones
//**********************************************************************************************
#include <xc.h>
#include <stdint.h>
#include <stdio.h>
#include "config.h"
#include "I2C.h"
#include "LCD.h"
//**********************************************************************************************
//prototipo de funciones
//**********************************************************************************************
void setup(void);
uint8_t bcd_to_decimal(uint8_t bdc);
void pantalla(void);
//**********************************************************************************************
//variables
//**********************************************************************************************

#define _XTAL_FREQ 1000000

uint8_t contador ;

//**********************************************************************************************
//ISR
//**********************************************************************************************
void __interrupt() isr(void)
{

}


//**********************************************************************************************
//Codigo principal
//**********************************************************************************************
void main() {
    setup();

    uint8_t contador = 0;
    uint8_t objeto_detectado = 0;  // Variable para rastrear si se ha detectado un objeto
    uint8_t contador2 = 0;
    uint8_t objeto_detectado2 = 0;  // Variable para rastrear si se ha detectado un objeto
    uint8_t contQ1 = 0;

    
    while(1) {
        pantalla();  // Funci?n para mostrar datos en la LCD

        if (RC0 == 1) {  // Si el sensor detecta un objeto
            if (!objeto_detectado) {  // Verifica si a?n no se ha detectado un objeto
                contador++;  // Incrementa el contador solo si no se ha detectado un objeto previamente
                objeto_detectado = 1;  // Marca que se ha detectado un objeto
                __delay_ms(500);  // Espera un tiempo para evitar contar m?ltiples veces por un solo objeto
            }
        } else {
            objeto_detectado = 0;  // Restablece la marca de detecci?n cuando no se detecta ning?n objeto
        }
        
        if (RC1 == 1) {  // Si el sensor detecta un objeto
            if (!objeto_detectado2) {  // Verifica si a?n no se ha detectado un objeto
                contador2++;  // Incrementa el contador solo si no se ha detectado un objeto previamente
                objeto_detectado2 = 1;  // Marca que se ha detectado un objeto
                __delay_ms(500);  // Espera un tiempo para evitar contar m?ltiples veces por un solo objeto
            }
        } else {
            objeto_detectado2 = 0;  // Restablece la marca de detecci?n cuando no se detecta ning?n objeto
        }

         float resultado = contador + (contador2 * 0.5);
        
        
        // Enciende los LEDs seg?n el valor de contador (1, 5, 10)
        if (contador2 >= 1) {
            RA0 = 1;
        } else {
            RA0 = 0;
        }

        if (contador2 >= 2) {
            RA1 = 1;
        } else {
            RA1 = 0;
        }

        if (contador2 >= 3) {
            RA2 = 1;
        } else {
            RA2 = 0;
        }
        if (contador2 >= 5) {
            RA3 = 1;
        } else {
            RA3 = 0;
        }
     
        
 ///////////////////////// Q 1   ////////////////////////////////////////////////
    char contador_str[4]; // Selecciona un tama?o suficiente para tu contador
    sprintf(contador_str, "%d", contador); // Convierte el contador a una cadena de caracteres
    char contador2_str[4]; // Selecciona un tama?o suficiente para tu contador
    sprintf(contador2_str, "%d", contador2); // Convierte el contador a una cadena de caracteres

    char resultado_str[10]; // Ajusta el tama?o seg?n tus necesidades
    sprintf(resultado_str, "%.2f", resultado); // Convierte el resultado a una cadena de caracteres con dos decimales
    
    
    // Borra la l?nea actual de la LCD y muestra el contador
    Lcd_Set_Cursor(1, 1); // Posici?n en la primera l?nea
    Lcd_Write_String("Q1"); // Borra la l?nea
    Lcd_Set_Cursor(2, 1); // Posici?n despu?s de "Contador: "
    Lcd_Write_String(contador_str); // Muestra el contador
    ///////////////////////// Q0.50   ////////////////////////////////////////////////
    Lcd_Set_Cursor(1, 5); // Posici?n en la primera l?nea
    Lcd_Write_String("Q0.50"); // Borra la l?nea
    Lcd_Set_Cursor(2, 5); // Posici?n despu?s de "Contador: "
    Lcd_Write_String(contador2_str); // Muestra el contador
        ///////////////////////// Q0.50   ////////////////////////////////////////////////


    Lcd_Set_Cursor(1, 12); // Posici?n en la primera l?nea
    Lcd_Write_String("Total"); // Borra la l?nea
    Lcd_Set_Cursor(2, 12); // Posici?n despu?s de "Resultado: "
    Lcd_Write_String(resultado_str); // Muestra el resultado en la LCD
    
    __delay_ms(15000);
        
        // Borrar la LCD
        Lcd_Clear();
        
        // Mostrar el nuevo mensaje en la LCD
        Lcd_Set_Cursor(1, 1);
        Lcd_Write_String("Nuevo mensaje");

    
    }

    return;
}
//**********************************************************************************************
//Codigo de configuracion
//**********************************************************************************************
void setup(){
    
    configOsc(8); //configuracion del oscilador
    configPort(); //configuracion de puertos   
    I2C_Master_Init(100000);
    Lcd_Init();
    configIntbits();
    pullup();
    return;
}

void pantalla(void){
    
    //dato adc slave
   // Lcd_Set_Cursor(1,1);
   // Lcd_Write_String("CONTADO Q1");
    //Lcd_Set_Cursor(2,6);
   // contador2 = contador;
   
   // Lcd_Write_String(contador);
    //sprintf(Resadc,"%d  ",contador);
    //Lcd_Write_String(Resadc);
    
    //dato hora rtc
   // Lcd_Set_Cursor(1,5);
    //Lcd_Write_String("H /D /M /A");
    
    
   //dato fecha rtc

    
    return;
    
}
