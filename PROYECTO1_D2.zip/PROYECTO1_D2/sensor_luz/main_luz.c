/*
 * File:   main.c
 * Author: cuyog
 *
 * Created on 21 de agosto de 2023, 17:01
 */

#include <xc.h>
#include <stdint.h>
#include <pic16f887.h>
#include "I2C.h"

#define _XTAL_FREQ 1000000

// Definiciones de pines
#define LIGHT_SENSOR_PIN    RA2 // Pin del sensor de luz
#define LED_PIN             RB0 // Pin del LED
#define LED_PIN2            RB1 // Pin del LED



// Prototipos de funciones
void ADC_Init();
uint16_t ADC_Read(uint8_t channel);

void main() {
    setup();
    
    while(1) {
        // Leer valor del sensor de luz
        uint16_t lightSensorValue = ADC_Read(2); // Lee el canal 2 del ADC (RA2)
        
        // Env?a el valor del sensor de luz al otro PIC a trav?s de I2C
        I2C_Master_Start(); // Inicia la comunicaci?n I2C
        I2C_Master_Write(0x50); // Direcci?n del dispositivo esclavo (segundo PIC)
        I2C_Master_Write(lightSensorValue >> 8); // Env?a byte m?s significativo
        I2C_Master_Write(lightSensorValue & 0xFF); // Env?a byte menos significativo
        I2C_Master_Stop(); // Detiene la comunicaci?n I2C
        
    // Configuraciones iniciales
    TRISAbits.TRISA2 = 1; // Configura solo el pin RA2 como entrada
    TRISB0 = 0;         // Configura todo el Puerto B como salidas
    ADC_Init();           // Inicializa el m?dulo ADC
    
    while(1) {
        // Iniciar una conversi?n ADC
        ADCON0bits.GO_nDONE = 1;

        // Esperar hasta que la conversi?n se complete
        while (ADCON0bits.GO_nDONE);

        // Leer el resultado de la conversi?n
        uint16_t adcValue = (ADRESH << 8) + ADRESL;
        
        // Calcular el valor l?mite para encender el LED (50%)
        uint16_t valorLimite = 1023 * 0.5; // 1023 es el valor m?ximo del ADC
        
        // Encender el LED si el valor del sensor es mayor al valor l?mite
        if (adcValue > valorLimite) {
            LED_PIN = 1; // Enciende el LED
        } 
        else {
            LED_PIN = 0; // Apaga el LED
        }
    }
}

void ADC_Init() {
    ADCON0 = 0b01001001; // Configura el ADC: Fosc/8, canal 2 (RA2)
    ADCON1 = 0b00000000; // Voltajes de referencia internos
    
}
}



